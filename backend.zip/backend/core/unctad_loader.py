import requests
from django.utils import timezone
from core.models import Port

UNCTAD_API = "https://unctadstat-api.unctad.org/port-data"  # example

def fetch_unctad_ports():
    response = requests.get(UNCTAD_API)

    if response.status_code != 200:
        return

    data = response.json()

    for p in data:
        Port.objects.update_or_create(
            name=p["port_name"],
            defaults={
                "country": p["country"],
                "avg_wait_time": p["avg_wait_time"],
                "arrivals": p["arrivals"],
                "departures": p["departures"],
                "congestion_score": p["congestion_index"],
                "last_update": timezone.now()
            }
        )
